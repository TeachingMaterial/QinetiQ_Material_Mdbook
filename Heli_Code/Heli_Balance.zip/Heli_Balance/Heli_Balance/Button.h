#ifndef PARSER_H
#define PARSER_H

void DoClick();
void DoDoubleClick();

#endif
